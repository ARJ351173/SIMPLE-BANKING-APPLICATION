package BankingManagementSystem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;

public class BankingSystem extends JFrame {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/banking_system";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "12345678";

    public BankingSystem() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Banking Management System");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        BankingAppPanel mainPanel = new BankingAppPanel();
        add(mainPanel);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BankingSystem::new);
    }
}

class BankingAppPanel extends JPanel {
    private JButton registerButton;
    private JButton loginButton;

    public BankingAppPanel() {
        initComponents();
        setLayout(new BorderLayout());
        add(createWelcomeLabel(), BorderLayout.NORTH);
        add(createButtonPanel(), BorderLayout.CENTER);
        setBorder(new EmptyBorder(50, 150, 50, 150));
        setBackground(Color.blue);
    }

    private JLabel createWelcomeLabel() {
        JLabel welcomeLabel = new JLabel("Welcome to the Banking Management System");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.BLUE);
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        welcomeLabel.setBorder(new EmptyBorder(20, 0, 20, 0));
        return welcomeLabel;
    }

    private void initComponents() {
        registerButton = new JButton("Register");
        loginButton = new JButton("Login");

        registerButton.setBackground(new Color(0, 128, 0)); // Dark green
        loginButton.setBackground(new Color(255, 165, 0)); // Orange
        registerButton.setForeground(Color.red);
        loginButton.setForeground(Color.red);
        registerButton.setFont(new Font("Arial", Font.BOLD, 18));
        loginButton.setFont(new Font("Arial", Font.BOLD, 18));

        registerButton.addActionListener(e -> new RegistrationForm().setVisible(true));
        loginButton.addActionListener(e -> new LoginForm().setVisible(true));
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 20, 20));
        buttonPanel.setBackground(Color.black);
        buttonPanel.add(registerButton);
        buttonPanel.add(loginButton);
        return buttonPanel;
    }
}

class RegistrationForm extends JDialog {
    private JTextField fullNameField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JPasswordField pinField;
    private JButton registerButton;

    public RegistrationForm() {
        initComponents();
        setTitle("Registration");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(400, 350);
        setLocationRelativeTo(null);
        setModal(true);
    }

    private void initComponents() {
        JLabel fullNameLabel = new JLabel("Full Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        JLabel pinLabel = new JLabel("PIN:");

        fullNameField = new JTextField(20);
        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);
        confirmPasswordField = new JPasswordField(20);
        pinField = new JPasswordField(4);

        registerButton = new JButton("Register");

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        formPanel.add(fullNameLabel);
        formPanel.add(fullNameField);
        formPanel.add(emailLabel);
        formPanel.add(emailField);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);
        formPanel.add(confirmPasswordLabel);
        formPanel.add(confirmPasswordField);
        formPanel.add(pinLabel);
        formPanel.add(pinField);

        registerButton.addActionListener(e -> registerUser());

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(formPanel, BorderLayout.NORTH);
        getContentPane().add(registerButton, BorderLayout.SOUTH);
    }

    private void registerUser() {
        String fullName = fullNameField.getText();
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String pin = new String(pinField.getPassword());

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.");
            return;
        }

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_system", "root", "12345678")) {
            String insertUserQuery = "INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)";
            String insertAccountQuery = "INSERT INTO accounts (full_name, email, balance, security_pin) VALUES (?, ?, ?, ?)";

            try (PreparedStatement insertUserStatement = connection.prepareStatement(insertUserQuery, Statement.RETURN_GENERATED_KEYS);
                 PreparedStatement insertAccountStatement = connection.prepareStatement(insertAccountQuery)) {

                connection.setAutoCommit(false);

                insertUserStatement.setString(1, fullName);
                insertUserStatement.setString(2, email);
                insertUserStatement.setString(3, password);
                int rowsInsertedUser = insertUserStatement.executeUpdate();

                if (rowsInsertedUser == 0) {
                    throw new SQLException("User insertion failed, no rows affected.");
                }

                insertAccountStatement.setString(1, fullName);
                insertAccountStatement.setString(2, email);
                insertAccountStatement.setDouble(3, 0.0); // Initial balance
                insertAccountStatement.setString(4, pin);
                int rowsInsertedAccount = insertAccountStatement.executeUpdate();

                if (rowsInsertedAccount == 0) {
                    throw new SQLException("Account insertion failed, no rows affected.");
                }

                JOptionPane.showMessageDialog(this, "Registration successful!");
                connection.commit();
                dispose();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Registration failed. Please try again later.");
        }
    }
}

class LoginForm extends JDialog {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginForm() {
        initComponents();
        setTitle("Login");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(400, 200);
        setLocationRelativeTo(null);
        setModal(true);
    }

    private void initComponents() {
        JLabel emailLabel = new JLabel("Email:");
        JLabel passwordLabel = new JLabel("Password:");

        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);

        loginButton = new JButton("Login");
        JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        formPanel.add(emailLabel);
        formPanel.add(emailField);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);

        loginButton.addActionListener(e -> authenticateUser());

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(formPanel, BorderLayout.NORTH);
        getContentPane().add(loginButton, BorderLayout.SOUTH);
    }

    private void authenticateUser() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_system", "root", "12345678")) {
            String query = "SELECT * FROM users WHERE email = ? AND password = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, email);
                statement.setString(2, password);

                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    JOptionPane.showMessageDialog(this, "Login successful!");
                    dispose();
                    new MainMenu(resultSet.getString("email")).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid email or password.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Login failed. Please try again later.");
        }
    }
}

class MainMenu extends JFrame {
    private JButton debitButton;
    private JButton creditButton;
    private JButton logoutButton;
    private JLabel balanceLabel;
    private JLabel welcomeLabel;
    private String userEmail;

    public MainMenu(String userEmail) {
        this.userEmail = userEmail;
        initComponents();
        setTitle("Main Menu");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(400, 200);
        setLocationRelativeTo(null);
        loadBalance();
        loadWelcomeLabel();
    }

    private void initComponents() {
        debitButton = new JButton("Debit");
        creditButton = new JButton("Credit");
        logoutButton = new JButton("Logout");
        balanceLabel = new JLabel();
        welcomeLabel = new JLabel();

        JPanel buttonPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        buttonPanel.add(welcomeLabel);
        buttonPanel.add(debitButton);
        buttonPanel.add(creditButton);
        buttonPanel.add(balanceLabel);
        buttonPanel.add(logoutButton);

        add(buttonPanel, BorderLayout.CENTER);

        debitButton.addActionListener(e -> performDebitAction());
        creditButton.addActionListener(e -> performCreditAction());
        logoutButton.addActionListener(e -> dispose());
    }

    private void loadWelcomeLabel() {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_system", "root", "12345678")) {
            String query = "SELECT full_name FROM users WHERE email = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, userEmail);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    String fullName = resultSet.getString("full_name");
                    welcomeLabel.setText("Welcome, " + fullName);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading user name. Please try again later.");
        }

        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setForeground(Color.BLUE);
        welcomeLabel.setHorizontalAlignment(SwingConstants.LEFT);
    }

    private void loadBalance() {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_system", "root", "12345678")) {
            String query = "SELECT balance FROM accounts WHERE email = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, userEmail);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    double balance = resultSet.getDouble("balance");
                    balanceLabel.setText("Balance: Rs. " + balance);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading balance. Please try again later.");
        }
    }

    private void performDebitAction() {
        String enteredPIN = JOptionPane.showInputDialog(this, "Enter your PIN for debit:");
        if (enteredPIN != null) {
            if (authenticatePIN(enteredPIN)) {
                String amountInput = JOptionPane.showInputDialog(this, "Enter the amount to debit:");
                if (amountInput != null) {
                    try {
                        double amount = Double.parseDouble(amountInput);
                        if (debitAmount(amount)) {
                            JOptionPane.showMessageDialog(this, "Debit action performed for amount: " + amount);
                            loadBalance(); // Update balance after debit action
                        } else {
                            JOptionPane.showMessageDialog(this, "Insufficient balance.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this, "Please enter a valid numerical amount.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid PIN. Debit action aborted.");
            }
        }
    }

    private boolean debitAmount(double amount) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_system", "root", "12345678")) {
            String updateQuery = "UPDATE accounts SET balance = balance - ? WHERE email = ?";
            try (PreparedStatement statement = connection.prepareStatement(updateQuery)) {
                statement.setDouble(1, amount);
                statement.setString(2, userEmail);
                int rowsAffected = statement.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Debit action failed. Please try again later.");
            return false;
        }
    }

    private void performCreditAction() {
        String enteredPIN = JOptionPane.showInputDialog(this, "Enter your PIN for credit:");
        if (enteredPIN != null) {
            if (authenticatePIN(enteredPIN)) {
                String amountInput = JOptionPane.showInputDialog(this, "Enter the amount to credit:");
                if (amountInput != null) {
                    try {
                        double amount = Double.parseDouble(amountInput);
                        creditAmount(amount);
                        JOptionPane.showMessageDialog(this, "Credit action performed for amount: " + amount);
                        loadBalance(); // Update balance after credit action
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this, "Please enter a valid numerical amount.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid PIN. Credit action aborted.");
            }
        }
    }

    private void creditAmount(double amount) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_system", "root", "12345678")) {
            String updateQuery = "UPDATE accounts SET balance = balance + ? WHERE email = ?";
            try (PreparedStatement statement = connection.prepareStatement(updateQuery)) {
                statement.setDouble(1, amount);
                statement.setString(2, userEmail);
                statement.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Credit action failed. Please try again later.");
        }
    }

    private boolean authenticatePIN(String enteredPIN) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_system", "root", "12345678")) {
            String query = "SELECT security_pin FROM accounts WHERE email = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, userEmail);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    String correctPIN = resultSet.getString("security_pin");
                    return enteredPIN.equals(correctPIN);
                } else {
                    return false; // User not found
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false; // Error in database query
        }
    }
}